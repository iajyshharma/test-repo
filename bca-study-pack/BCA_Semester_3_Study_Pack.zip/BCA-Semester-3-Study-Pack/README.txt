BCA SEMESTER III - ENGLISH STUDY PACK

CONTENTS
- PDFs/: five combined subject books (notes + solved practicals).
- resources/: ten separate PDFs and five source-code ZIPs, preloaded in the portal.
- app.py: complete portal source (HTML/CSS/JavaScript frontend embedded in Python).
- catalog.json: default library entries.
- OPEN_NOTES.html: offline index for opening the PDFs without Python.

COVERAGE
Web Designing: all 18 official practicals.
Linux Server Administration: all 10 official practicals, including command-reference procedures.
RDBMS Using MySQL: all 10 official practicals.
Linux & Shell Programming: all 20 official practicals.
Operating Systems: five theory units and 8 clearly labelled supplementary solved exercises.
Total: 58 official practical solutions, 8 supplementary OS exercises, and 25 explained theory units.
Source: BCA-CBCS-Syllabus-2021.pdf uploaded by the user; its internal headers state BCA-2020.
The selected syllabus pages are 42-46, 49-52 and 55-56. Multimedia is the unselected alternative.

WINDOWS QUICK START
1. Extract this entire ZIP before running anything.
2. PDFs can be opened directly from PDFs/ or through OPEN_NOTES.html.
3. For the portal, install Python 3.10+ with the Windows py launcher if not already installed.
4. Double-click START.bat. Keep the new terminal open while using the portal.
5. The browser opens automatically on a free local port. Its address is also printed.
6. To create a separate Desktop project and open VS Code, use SETUP_ON_DESKTOP.bat.
7. Stop the server with Ctrl+C in its terminal.

PORTAL FEATURES
Choose subject/category, search, preview PDFs and images, read source/text files,
upload your own files (maximum 10 MB each), write notes, download files and export a backup.
Word, PowerPoint and ZIP files can be downloaded for their installed applications.
Your imported files are copied into data/files. Removing a library copy leaves its original alone.
Use Download Backup regularly; it includes the SQLite library and its referenced files.
This is a local single-user study tool, not a cloud account/synchronization service.

RUNNING LAB SOURCE
Extract the appropriate source ZIP into its own working folder.
Linux scripts need Bash and GNU/Linux/WSL, with utilities listed in each solution.
MySQL exercises need a MySQL 8.x server/client. Reset the disposable EMP baseline before each independent experiment.
OS simulations use Python 3.10+. Web examples use the included Python teaching server.
Web practical 14 deliberately uses SQLite with a Python HTTP backend; the RDBMS workbook separately uses MySQL.

VALIDATION AND LIMITS
68 academic source checks completed (syntax and selected shell executions plus all 8 OS programs).
32 portal integration checks passed, including all PDF endpoints, file integrity, backups and restart persistence.
The earlier Web practical suite passed 65 checks; native print-dialog interaction was not performed.
MySQL queries were reviewed and expected values calculated; they were not executed against a MySQL server here.
Privileged Linux mail/DNS/FTP/SSH/VNC configurations are documented procedures, not claimed live deployments.
Calendar/bc tools, GUI editors, printing hardware and hosting checks depend on the laboratory setup.
Expected output is distinguished from observed output. Add your own lab observations and teacher remarks.
The notes are explained revision guides, not full textbooks or a guarantee of examination coverage.
The practical workbooks explicitly explain ambiguous syllabus wording (LCD, data/date format, creation timestamps).
