"""College Study Portal: Python 3.10+, no external packages."""
import base64
import binascii
from contextlib import contextmanager
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json
import mimetypes
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from threading import RLock
from urllib.parse import quote, urlparse
import uuid
import webbrowser
import zipfile

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
UPLOADS = DATA / "files"
DB = DATA / "library.sqlite3"
MAX_FILE = 10 * 1024 * 1024
LIBRARY_LOCK = RLock()
KINDS = {"Notes", "Practicals", "Projects", "Photos", "Other"}
IMAGES = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
TEXT = {".txt", ".md", ".csv", ".py", ".html", ".css", ".js", ".json", ".sql", ".c", ".cpp", ".java", ".sh"}

PAGE = r'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>BCA Semester 3 - College Study Portal</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f9;color:#243247;font:15px/1.6 Arial,sans-serif}
button,input,select,textarea{font:inherit}button,a{touch-action:manipulation}button{cursor:pointer}
header{background:#173658;color:white;padding:28px max(24px,calc((100% - 1180px)/2))}
header h1{margin:0;font-size:28px}header p{margin:5px 0 0;color:#cedaeb}
.wrap{max-width:1228px;margin:auto;padding:24px}.summary{display:flex;gap:14px;margin-bottom:22px}
.stat{background:white;border:1px solid #e0e6ef;border-radius:10px;padding:14px 20px;flex:1}
.stat strong{display:block;font-size:26px;color:#173658}.stat span,.muted{color:#627188}
.layout{display:grid;grid-template-columns:205px minmax(0,1fr);gap:22px}
aside{align-self:start;background:white;border:1px solid #e0e6ef;border-radius:10px;padding:14px}
aside button{display:block;width:100%;padding:11px;text-align:left;border:0;border-radius:6px;background:white;color:#35465f}
aside button.active{background:#e8f0fb;color:#173658;font-weight:bold}aside hr{border:0;border-top:1px solid #e0e6ef}
aside small{display:block;padding:9px;color:#627188}.toolbar{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:18px}
input,select,textarea{border:1px solid #bbc8d8;border-radius:6px;padding:10px;background:white;color:#243247;max-width:100%}
#search{flex:1;min-width:150px}button.primary,.download{background:#245a92;color:white;border:0;border-radius:6px;padding:10px 15px;text-decoration:none}
button.secondary{background:white;color:#245a92;border:1px solid #bbc8d8;border-radius:6px;padding:9px 13px}
button:hover{filter:brightness(.96)}button:disabled{opacity:.55;cursor:wait}
h2{margin:0;font-size:22px}.heading{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:20px 0 14px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(225px,1fr));gap:14px}
.card{background:white;border:1px solid #e0e6ef;border-radius:10px;padding:18px;min-width:0}
.filetype{display:inline-block;background:#edf3fa;border-radius:6px;color:#245a92;padding:7px 10px;font-size:12px;font-weight:bold}
.card h3{font-size:16px;margin:12px 0 5px;overflow-wrap:anywhere}.card p{margin:4px 0;color:#627188;font-size:13px}
.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.actions button{border:0;background:#edf3fa;color:#245a92;padding:7px 12px;border-radius:5px}
.actions a{color:#245a92;padding:7px 0}.empty{padding:45px 20px;border:1px dashed #bbc8d8;border-radius:10px;text-align:center;background:white}
dialog{border:0;border-radius:12px;padding:24px;width:550px;max-width:calc(100% - 24px);max-height:90vh;color:#243247;box-shadow:0 20px 70px #0003}
dialog::backdrop{background:#13243b99}dialog label{display:block;font-weight:bold;margin:14px 0 5px}dialog input,dialog select,dialog textarea{width:100%}
dialog h2{margin-right:30px}.close{float:right;background:none;border:0;font-size:24px;line-height:1}.dialog-actions{display:flex;gap:10px;margin-top:18px}
#preview{width:950px}#viewer{margin-top:20px}#viewer img{display:block;max-width:100%;max-height:65vh;margin:auto}
#viewer iframe{width:100%;height:65vh;border:1px solid #e0e6ef}#viewer pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f4f6f9;padding:16px;max-height:65vh;overflow:auto}
#notice{padding:12px;border-radius:6px;background:#e5f1ea;margin-bottom:16px;overflow-wrap:anywhere}#notice:empty{display:none}.hint{font-size:13px;color:#627188}
:focus-visible{outline:3px solid #5794d0;outline-offset:3px}[hidden]{display:none!important}
@media(max-width:700px){header{padding:22px}header h1{font-size:24px}.wrap{padding:14px}.layout{grid-template-columns:1fr}aside{display:flex;flex-wrap:wrap;gap:5px}aside button{width:auto}aside small,aside hr{display:none}.summary{gap:8px}.stat{padding:10px}.stat strong{font-size:22px}.toolbar>*{flex:1}.heading{align-items:start}}
</style>
</head>
<body>
<header><h1>College Study Portal</h1><p>BCA Semester 3 · RDBMS, OS, LSA, LSP and Web Designing</p></header>
<div class="wrap"><p class="hint">Makhanlal Chaturvedi University, Bhopal · English notes and solved practicals mapped to your uploaded syllabus.</p>
<section class="summary" aria-label="Library summary">
<div class="stat"><strong id="subjectCount">0</strong><span>Subjects</span></div>
<div class="stat"><strong id="fileCount">0</strong><span>Saved files</span></div>
<div class="stat"><strong id="storage">0 KB</strong><span>Library size</span></div>
</section>
<div class="layout">
<aside aria-label="Categories">
<button class="active" data-kind="All">All Files</button>
<button data-kind="Notes">Notes</button><button data-kind="Practicals">Practicals</button>
<button data-kind="Projects">Projects</button><button data-kind="Photos">Photos</button><button data-kind="Other">Other Files</button>
<hr><button id="addSubject">+ Add Subject</button><button id="backup">Download Backup</button>
<small>Your added files stay in this local library.</small>
</aside>
<main>
<div id="notice" role="status" aria-live="polite"></div>
<div class="toolbar">
<input id="search" type="search" placeholder="Search files or subjects..." aria-label="Search files">
<select id="subjectFilter" aria-label="Filter subject"><option value="">All subjects</option></select>
<button class="primary" id="addFiles">+ Add Files</button>
<button class="secondary" id="writeNote">Write a Note</button>
</div>
<div class="heading"><h2 id="sectionTitle">All Files</h2><span class="muted" id="resultCount"></span></div>
<div id="grid" class="grid"></div>
<div id="empty" class="empty" hidden><h3>No matching files</h3><p>Add your files or change the search and filters.</p></div>
</main>
</div>
</div>

<dialog id="subjectDialog"><button class="close" aria-label="Close" data-close>&times;</button>
<h2>Add Subject</h2><form id="subjectForm">
<label for="subjectName">Subject name</label><input id="subjectName" required maxlength="80" placeholder="For example: Database Management Systems">
<div class="dialog-actions"><button class="primary">Save Subject</button></div></form></dialog>

<dialog id="uploadDialog"><button class="close" aria-label="Close" data-close>&times;</button>
<h2>Add Files</h2><form id="uploadForm">
<label for="uploadSubject">Subject</label><select id="uploadSubject" required></select>
<label for="uploadKind">Category</label><select id="uploadKind"><option>Notes</option><option>Practicals</option><option>Projects</option><option>Photos</option><option>Other</option></select>
<label for="uploadFiles">Choose one or more files</label><input id="uploadFiles" type="file" multiple required>
<p class="hint">Up to 10 MB per file. Upload PDFs, images, documents, code or project ZIPs.</p>
<p id="uploadProgress" role="status"></p><div class="dialog-actions"><button class="primary" id="uploadButton">Save Files</button></div>
</form></dialog>

<dialog id="noteDialog"><button class="close" aria-label="Close" data-close>&times;</button>
<h2>Write a Note</h2><form id="noteForm">
<label for="noteSubject">Subject</label><select id="noteSubject" required></select>
<label for="noteTitle">Title</label><input id="noteTitle" required maxlength="100" placeholder="Unit 1 - Introduction">
<label for="noteText">Your notes</label><textarea id="noteText" rows="10" required maxlength="200000" placeholder="Write your notes here..."></textarea>
<div class="dialog-actions"><button class="primary">Save Note</button></div></form></dialog>

<dialog id="preview"><button class="close" aria-label="Close" data-close>&times;</button>
<h2 id="previewTitle"></h2><p class="muted" id="previewInfo"></p>
<a class="download" id="previewDownload">Download File</a><div id="viewer"></div></dialog>

<script>
const $ = id => document.getElementById(id);
let library = {subjects:[],files:[]}, category = 'All';
const sizes = n => n < 1024 ? n+' B' : n < 1048576 ? (n/1024).toFixed(1)+' KB' : (n/1048576).toFixed(1)+' MB';
function notify(text) { $('notice').textContent = text; }
async function api(path, data) {
  const response = await fetch(path, data === undefined ? {} : {
    method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Request failed.');
  return result;
}
function option(select, value, text) {
  const item = document.createElement('option'); item.value=value; item.textContent=text; select.append(item);
}
async function refresh() {
  const selected = $('subjectFilter').value;
  library = await api('/api/library');
  for (const id of ['subjectFilter','uploadSubject','noteSubject']) {
    $(id).replaceChildren();
    if (id === 'subjectFilter') option($(id),'','All subjects');
    library.subjects.forEach(s => option($(id),s.id,s.name));
  }
  $('subjectFilter').value=selected;
  $('subjectCount').textContent=library.subjects.length;
  $('fileCount').textContent=library.files.length;
  $('storage').textContent=sizes(library.files.reduce((n,f)=>n+f.size,0));
  render();
}
function render() {
  const query=$('search').value.trim().toLowerCase(), subject=$('subjectFilter').value;
  const files=library.files.filter(f => (category==='All'||f.kind===category)
    && (!subject||String(f.subject_id)===subject)
    && (f.name+' '+f.subject+' '+f.kind).toLowerCase().includes(query));
  $('sectionTitle').textContent=category==='All'?'All Files':category;
  $('resultCount').textContent=files.length+' files';
  $('grid').replaceChildren(); $('empty').hidden=files.length>0;
  files.forEach(file => {
    const card=document.createElement('article'); card.className='card';
    const badge=document.createElement('span'); badge.className='filetype';
    badge.textContent=file.name.includes('.')?file.name.split('.').pop().slice(0,8).toUpperCase():'FILE';
    const title=document.createElement('h3'); title.textContent=file.name.replace(/_/g,' ').replace(/\.(pdf|zip)$/i,'');
    const subject=document.createElement('p'); subject.textContent=file.subject+' · '+file.kind;
    const meta=document.createElement('p'); meta.textContent=sizes(file.size)+' · '+new Date(file.created).toLocaleDateString('en-IN',{timeZone:'Asia/Kolkata'});
    const actions=document.createElement('div'); actions.className='actions';
    const open=document.createElement('button'); open.textContent='Open'; open.onclick=()=>preview(file);
    const download=document.createElement('a'); download.textContent='Download'; download.href='/download/'+file.id;
    const remove=document.createElement('button'); remove.textContent='Remove';
    remove.onclick=async()=>{
      if (!confirm('Remove this library copy of '+file.name+'? Your original file is unchanged.')) return;
      try { await api('/api/remove',{id:file.id}); await refresh(); notify('Library copy removed.'); }
      catch(error) { notify(error.message); }
    };
    actions.append(open,download,remove); card.append(badge,title,subject,meta,actions); $('grid').append(card);
  });
}
async function preview(file) {
  $('previewTitle').textContent=file.name;
  $('previewInfo').textContent=file.subject+' · '+file.kind;
  $('previewDownload').href='/download/'+file.id; $('viewer').replaceChildren();
  $('preview').showModal();
  const ext='.'+file.name.split('.').pop().toLowerCase();
  if (['.png','.jpg','.jpeg','.gif','.webp'].includes(ext)) {
    const image=document.createElement('img'); image.src='/view/'+file.id; image.alt=file.name; $('viewer').append(image);
  } else if (ext==='.pdf') {
    const frame=document.createElement('iframe'); frame.src='/view/'+file.id; frame.title=file.name; $('viewer').append(frame);
  } else if (['.txt','.md','.csv','.py','.html','.css','.js','.json','.sql','.c','.cpp','.java','.sh'].includes(ext)) {
    const box=document.createElement('pre'); box.textContent='Loading...'; $('viewer').append(box);
    try {
      const response=await fetch('/text/'+file.id);
      if (!response.ok) throw new Error('Could not read this file.');
      box.textContent=await response.text();
    } catch(error) { box.textContent=error.message; }
  } else {
    const text=document.createElement('p'); text.textContent='Download this file to open it with its application on your computer.';
    $('viewer').append(text);
  }
}
function base64File(file) {
  return new Promise((resolve,reject)=>{
    const reader=new FileReader(); reader.onload=()=>resolve(reader.result.split(',')[1]);
    reader.onerror=()=>reject(new Error('Could not read '+file.name)); reader.readAsDataURL(file);
  });
}
document.querySelectorAll('[data-close]').forEach(button=>button.onclick=()=>button.closest('dialog').close());
$('preview').addEventListener('close',()=>$('viewer').replaceChildren());
document.querySelectorAll('[data-kind]').forEach(button=>button.onclick=()=>{
  category=button.dataset.kind;
  document.querySelectorAll('[data-kind]').forEach(b=>b.classList.toggle('active',b===button)); render();
});
$('search').oninput=render; $('subjectFilter').onchange=render;
$('addSubject').onclick=()=>$('subjectDialog').showModal();
$('addFiles').onclick=()=>{
  if ($('subjectFilter').value) $('uploadSubject').value=$('subjectFilter').value;
  $('uploadProgress').textContent=''; $('uploadDialog').showModal();
};
$('writeNote').onclick=()=>{
  if ($('subjectFilter').value) $('noteSubject').value=$('subjectFilter').value;
  $('noteDialog').showModal();
};
$('backup').onclick=()=>{window.location.href='/backup';};
$('subjectForm').onsubmit=async event=>{
  event.preventDefault();
  try { const result=await api('/api/subject',{name:$('subjectName').value}); await refresh();
    $('subjectFilter').value=result.id; render(); $('subjectForm').reset(); $('subjectDialog').close(); notify('Subject added.'); }
  catch(error) { alert(error.message); }
};
$('noteForm').onsubmit=async event=>{
  event.preventDefault();
  try { await api('/api/note',{subject_id:Number($('noteSubject').value),title:$('noteTitle').value,text:$('noteText').value});
    await refresh(); $('noteForm').reset(); $('noteDialog').close(); notify('Note saved.'); }
  catch(error) { alert(error.message); }
};
$('uploadForm').onsubmit=async event=>{
  event.preventDefault(); const files=Array.from($('uploadFiles').files);
  if (files.some(f=>f.size>10485760)) { alert('Each file must be 10 MB or smaller.'); return; }
  $('uploadButton').disabled=true; let saved=0;
  try {
    for (const file of files) {
      $('uploadProgress').textContent='Saving '+file.name+'...';
      await api('/api/upload',{subject_id:Number($('uploadSubject').value),kind:$('uploadKind').value,
        name:file.name,content:await base64File(file)}); saved++;
    }
    $('uploadFiles').value=''; $('uploadDialog').close(); notify(saved+' file(s) saved.');
  } catch(error) { alert(saved+' file(s) saved. '+error.message); }
  finally { $('uploadButton').disabled=false; await refresh(); }
};
refresh().catch(error=>notify(error.message));
</script>
</body></html>'''

@contextmanager
def connect():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def clean_name(name):
    name = str(name).replace("\\", "/").split("/")[-1]
    name = "".join(c for c in name if c.isprintable()).strip()
    if not name or name in {".", ".."} or len(name) > 180:
        raise ValueError("Enter a file name with 1 to 180 characters.")
    return name

def save_file(subject_id, kind, name, content):
    name = clean_name(name)
    if kind not in KINDS:
        raise ValueError("Select a valid category.")
    if len(content) > MAX_FILE:
        raise ValueError("The file exceeds the 10 MB limit.")
    stored = uuid.uuid4().hex
    with connect() as db:
        if not db.execute("SELECT id FROM subjects WHERE id=?", (subject_id,)).fetchone():
            raise ValueError("Please select an existing subject.")
        path = UPLOADS / stored
        path.write_bytes(content)
        try:
            row = db.execute("INSERT INTO files(subject_id,kind,name,stored,size,created) VALUES(?,?,?,?,?,?)",
                (subject_id, kind, name, stored, len(content), datetime.now().astimezone().isoformat(timespec="seconds")))
            db.commit()
            return row.lastrowid
        except Exception:
            path.unlink(missing_ok=True)
            raise

def initialize():
    first_run = not DB.exists()
    UPLOADS.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.executescript('''CREATE TABLE IF NOT EXISTS subjects(
          id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY,
          subject_id INTEGER NOT NULL REFERENCES subjects(id), kind TEXT NOT NULL,
          name TEXT NOT NULL, stored TEXT NOT NULL UNIQUE, size INTEGER NOT NULL,
          created TEXT NOT NULL);''')
    if first_run:
        catalog = json.loads((ROOT / "catalog.json").read_text())
        subjects = {}
        for entry in catalog:
            name = entry["subject"]
            if name not in subjects:
                with connect() as db:
                    subjects[name] = db.execute("INSERT INTO subjects(name) VALUES(?)", (name,)).lastrowid
            path = ROOT / "resources" / entry["file"]
            save_file(subjects[name], entry["kind"], path.name, path.read_bytes())



class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def respond(self, status, content, content_type="application/json; charset=utf-8", extra=None):
        if isinstance(content, (dict, list)):
            content = json.dumps(content).encode()
        elif isinstance(content, str):
            content = content.encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(content)

    def send_file(self, path, name, inline=False, mime=None):
        with path.open("rb") as file:
            self.send_response(200)
            self.send_header("Content-Type", mime or "application/octet-stream")
            self.send_header("Content-Length", str(path.stat().st_size))
            disposition = "inline" if inline else "attachment"
            self.send_header("Content-Disposition", disposition + "; filename*=UTF-8''" + quote(name, safe=""))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            shutil.copyfileobj(file, self.wfile)

    def valid_host(self):
        port = self.server.server_port
        return self.headers.get("Host") in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def do_GET(self):
        if not self.valid_host():
            return self.respond(403, {"error": "Open the local portal address."})
        path = urlparse(self.path).path
        if path == "/":
            return self.respond(200, PAGE, "text/html; charset=utf-8")
        if path == "/api/library":
            with connect() as db:
                subjects = [dict(r) for r in db.execute("SELECT * FROM subjects ORDER BY name")]
                files = [dict(r) for r in db.execute("SELECT f.id,f.subject_id,f.kind,f.name,f.size,f.created,s.name AS subject FROM files f JOIN subjects s ON s.id=f.subject_id ORDER BY f.id DESC")]
            return self.respond(200, {"subjects": subjects, "files": files})
        if path == "/backup":
            with LIBRARY_LOCK, tempfile.TemporaryDirectory() as folder:
                snapshot = Path(folder) / "library.sqlite3"
                with connect() as source, sqlite3.connect(snapshot) as target:
                    source.backup(target)
                archive = Path(folder) / "College-Library-Backup.zip"
                with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
                    output.write(snapshot, "data/library.sqlite3")
                    with sqlite3.connect(snapshot) as db:
                        for (stored,) in db.execute("SELECT stored FROM files"):
                            file = UPLOADS / stored
                            if file.exists():
                                output.write(file, "data/files/" + stored)
                    output.writestr("RESTORE.txt", "Stop the portal. Keep a copy of your current data folder. Extract this backup and place its data folder beside app.py, then restart the portal.\n")
                return self.send_file(archive, archive.name)
        parts = path.strip("/").split("/")
        if len(parts) == 2 and parts[0] in {"view", "text", "download"} and parts[1].isdigit():
            with connect() as db:
                row = db.execute("SELECT * FROM files WHERE id=?", (int(parts[1]),)).fetchone()
            if not row or not (UPLOADS / row["stored"]).exists():
                return self.respond(404, {"error": "File not found."})
            file, extension = UPLOADS / row["stored"], Path(row["name"]).suffix.lower()
            if parts[0] == "text" and extension in TEXT:
                with file.open("rb") as source:
                    data = source.read(300000)
                suffix = "\n\n[Preview limited to 300 KB. Download for the full file.]" if row["size"] > 300000 else ""
                return self.respond(200, data.decode("utf-8", errors="replace") + suffix, "text/plain; charset=utf-8")
            if parts[0] == "view" and extension in IMAGES | {".pdf"}:
                return self.send_file(file, row["name"], True, mimetypes.guess_type(row["name"])[0])
            return self.send_file(file, row["name"])
        self.respond(404, {"error": "Not found."})

    def do_POST(self):
        with LIBRARY_LOCK:
            return self.handle_post()

    def handle_post(self):
        if not self.valid_host():
            return self.respond(403, {"error": "Open the local portal address."})
        origin = self.headers.get("Origin")
        port = self.server.server_port
        if origin and origin not in {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}:
            return self.respond(403, {"error": "Open the portal in its own browser tab."})
        if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
            return self.respond(415, {"error": "Expected a JSON request."})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 15 * 1024 * 1024:
                raise ValueError("Invalid request size.")
            data = json.loads(self.rfile.read(length))
            if not isinstance(data, dict):
                raise ValueError("Invalid request.")
            if self.path == "/api/subject":
                name = str(data.get("name", "")).strip()
                if not 1 <= len(name) <= 80:
                    raise ValueError("Subject name must have 1 to 80 characters.")
                with connect() as db:
                    identity = db.execute("INSERT INTO subjects(name) VALUES(?)", (name,)).lastrowid
            elif self.path == "/api/upload":
                content = base64.b64decode(data.get("content", ""), validate=True)
                identity = save_file(int(data["subject_id"]), data["kind"], data["name"], content)
            elif self.path == "/api/note":
                title, content = str(data.get("title", "")).strip(), str(data.get("text", ""))
                if not title or len(title) > 100 or not content.strip() or len(content) > 200000:
                    raise ValueError("Enter a title and note text within the limits.")
                identity = save_file(int(data["subject_id"]), "Notes", title + ".md", content.encode())
            elif self.path == "/api/remove":
                identity = int(data["id"])
                with connect() as db:
                    row = db.execute("SELECT stored FROM files WHERE id=?", (identity,)).fetchone()
                    if not row:
                        raise ValueError("File not found.")
                    db.execute("DELETE FROM files WHERE id=?", (identity,))
                (UPLOADS / row["stored"]).unlink(missing_ok=True)
            else:
                return self.respond(404, {"error": "Unknown action."})
            self.respond(200, {"ok": True, "id": identity})
        except sqlite3.IntegrityError:
            self.respond(409, {"error": "This subject already exists."})
        except (ValueError, KeyError, TypeError, binascii.Error):
            self.respond(400, {"error": "Check your input, file size and selected subject."})
        except (OSError, sqlite3.Error):
            self.respond(500, {"error": "Could not save the file. Check free disk space and folder permissions."})

def serve():
    initialize()
    server = ThreadingHTTPServer(("127.0.0.1", int(os.environ.get("PORTAL_PORT", "0"))), Handler)
    address = f"http://127.0.0.1:{server.server_port}/"
    print("College Study Portal: " + address, flush=True)
    if os.environ.get("PORTAL_NO_BROWSER") != "1":
        webbrowser.open(address)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()

def install():
    desktop = Path.home() / "Desktop"
    if os.name == "nt":
        import winreg
        key = r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key) as registry:
            desktop = Path(os.path.expandvars(winreg.QueryValueEx(registry, "Desktop")[0]))
    destination = desktop / "College-Study-Portal"
    number = 2
    while destination.exists() or destination.with_suffix(".zip").exists():
        destination = desktop / f"College-Study-Portal-{number}"
        number += 1
    destination.mkdir(parents=True)
    shutil.copyfile(Path(__file__).resolve(), destination / "app.py")
    shutil.copyfile(ROOT / "catalog.json", destination / "catalog.json")
    shutil.copytree(ROOT / "resources", destination / "resources")
    (destination / "START.bat").write_text('@echo off\ncd /d "%~dp0"\npy -3 app.py --serve\npause\n')
    (destination / "College-Study-Portal.code-workspace").write_text(json.dumps({"folders": [{"path": "."}]}))
    (destination / "README.txt").write_text(
        "Double-click START.bat to open the portal. Keep its terminal open.\n"
        "Add Subject: create your actual subject list. Add Files: import your own study material.\n"
        "Write a Note: create notes. PDFs, images and text/code files can be previewed.\n"
        "Word, PowerPoint, ZIP and other files can be downloaded and opened in their applications.\n"
        "English PDFs follow the uploaded syllabus. OS exercises are supplementary. See each workbook for validation limits.\n"
        "Files are copied into data/files; your originals remain where they were.\n"
        "Download Backup includes library data and files. Close the server with Ctrl+C.\n"
        "Requirements: Python 3.10+ with the Windows py launcher. No pip packages required.\n")
    shutil.make_archive(str(destination), "zip", destination.parent, destination.name)
    print("Project created: " + str(destination), flush=True)
    options = {"creationflags": subprocess.CREATE_NEW_CONSOLE} if os.name == "nt" else {}
    subprocess.Popen([sys.executable, "app.py", "--serve"], cwd=destination, **options)
    if os.name == "nt":
        try:
            os.startfile(str(destination / "College-Study-Portal.code-workspace"))
        except OSError:
            print("Open the project folder in VS Code manually.")

if __name__ == "__main__":
    if "--serve" in sys.argv:
        serve()
    else:
        install()
